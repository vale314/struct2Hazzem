//
//  main.cpp
//  TablasHash
//
//  Created by Oscar Sandoval on 4/6/19.
//  Copyright © 2019 Oscar Sandoval. All rights reserved.
//

#include "persona.hpp"
#include "console.hpp"
using namespace std;
int main(int argc, const char * argv[]) {
    string myStr;
    Persona persona;
    Console graphics;
    system("clear");
    cout<<persona.getColums()*sizeof(Data)+sizeof(long);cin.get();
    do{

        cout<<"Filas : "<<persona.getRows()<<"      Columnas : "<<persona.getColums()<<endl;
        cout<<"\t\t\tMenu Persona "<<endl
        <<"\t1)Crear"<<endl
        <<"\t2)Mostrar"<<endl
        <<"\t3)Modificar"<<endl
        <<"\t4)Eliminar"<<endl
        <<"\t5)Manejo de colisiones"<<endl
        <<"\t6)Salir"<<endl
        <<"\tElige una opcion : ";
        getline(cin,myStr);
        if(myStr=="1"){
            system("clear");
            cout<<"\t\t\tAgregar Persona"<<endl
            <<"\tNombre : ";
            getline(cin,myStr);
            persona.setName(myStr);
            do{
                cout<<"\tRfc : ";
                getline(cin,myStr);
            }while(persona.isValidRfc(myStr));
            persona.setRfc(myStr);
            cout<<"\tDireccion : ";
            getline(cin,myStr);
            persona.setAddress(myStr);
            cout<<"\tTelefono : ";
            getline(cin,myStr);
            persona.setPhone(myStr);
            persona.insert();
        }else if(myStr=="2"){
            system("clear");
            persona.print(graphics);
            system("clear");
        }else if(myStr=="3"){
            system("clear");
            cout<<"\t\tModificar Registro "<<endl
            <<"\tRFC : ";
            getline(cin,myStr);
            persona.mofify(myStr);
        }else if(myStr=="4"){
            system("clear");
            cout<<"\t\tEliminar  Registro "<<endl
            <<"\tRFC : ";
            getline(cin,myStr);
            persona.remove(myStr);
            
        }else if(myStr=="5"){
            system("clear");
            cout<<"\t\tManejo de Colisiones "<<endl
            <<"\t1)Expandir Filas"<<endl
            <<"\t2)Expandir Columnas"<<endl
            <<"\t3)Regresar"<<endl
            <<"\tElige una opcion : ";
            getline(cin,myStr);
            if(myStr=="1"){
                system("clear");
                cout<<"\t\tManejo de Colisiones "<<endl
                <<"Filas actuales : "<<persona.getRows()<<endl;
                persona.expandirFilas();
                cout<<"Las filas se expandieron a "<<persona.getRows()<<endl;
                cin.get();
            }else if(myStr=="2"){
                system("clear");
                cout<<"\t\tManejo de Colisiones "<<endl
                <<"Columnas actuales : "<<persona.getColums()<<endl;
                persona.expandirColumnas();
                cout<<"Las Columnas se expandieron a "<<persona.getColums()<<endl;
                cin.get();
            }else if(myStr=="3"){
                
            }else{
                system("clear");
                cout<<"Opcion no valida"<<endl;
            }
        }else if(myStr=="6"){
            
        }else{
            system("clear");
            cout<<"\tOpcion no valida "<<endl;
        }
    }while(myStr!="6");
    return 0;
}
