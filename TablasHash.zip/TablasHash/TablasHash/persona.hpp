//
//  persona.hpp
//  TablasHash
//
//  Created by Oscar Sandoval on 4/6/19.
//  Copyright © 2019 Oscar Sandoval. All rights reserved.
//

#ifndef persona_hpp
#define persona_hpp
#include <iostream>
#include "console.hpp"
class Data{
public:
    char rfc[8];
    char name[20];
    char address[30];
    char phone[12];
};
class Persona{
private:
    Data data;
    int rows;
    int columns;
    void copyFile();
    void insertCopy();
public:
    Persona();
    void setRfc(std::string&);
    void setName(std::string&);
    void setAddress(std::string&);
    void setPhone(std::string&);
    std::string getRfc();
    std::string getName();
    std::string getAddress();
    int getRows();
    int getColums();
    long getAddress(std::string);
    std::string getPhone();
    void insert();
    void print(Console&);
    void mofify(std::string&);
    void remove(std::string&);
    int dispersion(std::string);
    bool isValidRfc(std::string&);
    bool isValidColumns(std::string&);
    bool isValidRows(std::string&);
    void expandirFilas();
    void expandirColumnas();
};
#endif /* persona_hpp */
