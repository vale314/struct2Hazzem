//
//  persona.cpp
//  TablasHash
//
//  Created by Oscar Sandoval on 4/6/19.
//  Copyright © 2019 Oscar Sandoval. All rights reserved.
//

#include "persona.hpp"
#include <fstream>
#include <sstream>
using namespace std;
Persona::Persona() { 
    fstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt",ios::in);
    if(archive.good()){
        archive.close();
        string myStr;
        archive.open("/Users/oscarsandoval/Desktop/tablasHash/tablasHash/Colisiones.txt");
        while(getline(archive,myStr)){
            stringstream stream(myStr);
            getline(stream,myStr,'|');
            rows=stoi(myStr);
            getline(stream,myStr,'|');
            columns=stoi(myStr);
        }
        return;
    }
    string aux2;
    setRfc(aux2);
    setName(aux2);
    setPhone(aux2);
    setAddress(aux2);
    archive.open("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt",ios::app);
    const long aux=0;
    for(int i=0;i<100;i++){
        archive.write((char*)&aux,sizeof(long));
        for(int j=0;j<4;j++){
            archive.write((char*)&data,sizeof(data));
        }
    }
    archive.close();
    archive.open("/Users/oscarsandoval/Desktop/tablasHash/tablasHash/Colisiones.txt",ios::out);
    archive<<100<<"|"<<4<<endl;
    rows=100;
    columns=4;
}

void Persona::setRfc(std::string &rfc){
    for(int i=0;i<8;++i){
        this->data.rfc[i] = '\0';
    }
    for(int i=0;rfc[i];i++){
        this->data.rfc[i]=rfc[i];
    }
}

void Persona::setName(std::string &nme){
    for(int i=0;i<20;++i){
        this->data.name[i] = '\0';
    }
    for(int i=0;nme[i];i++){
        this->data.name[i]=nme[i];
    }
}

void Persona::setPhone(std::string &phone){
    for(int i=0;i<12;++i){
        this->data.phone[i] = '\0';
    }
    for(int i=0;phone[i];i++){
        this->data.phone[i]=phone[i];
    }
}

void Persona::setAddress(std::string &add){
    for(int i=0;i<30;++i){
        this->data.address[i] = '\0';
    }
    for(int i=0;add[i];i++){
        this->data.address[i]=add[i];
    }
}

string Persona::getName(){
    return data.name;
}

string Persona::getRfc(){
    return data.rfc;
}

string Persona::getAddress(){
    return data.address;
}

string Persona::getPhone(){
    return data.phone;
}

int Persona::getRows(){
    return rows;
}

int Persona::getColums(){
    return columns;
}

bool Persona::isValidRows(std::string &filas){
    int aux;
    try{
        aux=(stoi(filas));
    }catch(invalid_argument& ex){
        return true;
    }
    if(aux>rows)
        return false;
    return true;
}

bool Persona::isValidColumns(std::string &column){
    int aux;
    try{
        aux=(stoi(column));
    }catch(invalid_argument& ex){
        return true;
    }
    if(aux>columns)
        return false;
    return true;
}

bool Persona::isValidRfc(std::string& rfc){
    if(rfc.length()==6){
        ifstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
        int pos(0);
        long aux;
        Data persona;
        int i=0;
        while(!archive.eof()){
            archive.seekg(pos);
            archive.read((char*)&aux, sizeof(aux));
            if(archive.eof())break;
            if(aux>0){
                for(int i(0);i<aux;++i){
                    archive.read((char*)&persona, sizeof(Data));
                    if(persona.rfc==rfc)
                        return true;
                }
            }
            pos=pos+(sizeof(Data)*columns+sizeof(long));
            i++;
        }
        return false;
    }
    return true;
}

long Persona::getAddress(std::string rc){
    fstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt",ios::in|ios::out);
    int pos(0);
    long aux;
    long a;
    while(!archive.eof()){
        archive.seekg(pos,ios::beg);
        if(archive.eof())break;
        archive.read((char*)&aux, sizeof(aux));
        cout<<aux<<endl; cin.get();
        if(aux>0){
            for(int i=0;i<aux;i++){
                a=archive.tellg();
                archive.read((char*)&data, sizeof(Data));
                cout<<getRfc();cin.get();
                if(getRfc()==rc)
                    return a;
            }
        }
        pos=pos+(sizeof(Data)*columns+sizeof(long));
    }
    return -1;
}

void Persona::insert() { 
    fstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt",ios::in|ios::out);
    int hash(dispersion(getRfc()));
    long pos(hash*(columns*sizeof(data)+sizeof(long)));
    long cont;
    archive.seekg(pos);
    archive.read((char*)&cont, sizeof(long));
    cout<<cont<<endl;
    cin.get();
    if(cont==columns){
        cout<<"\t│                   NO HAY ESPACIO                  │\n";
        archive.close();
        cin.get();
        return;
    }
    long aux = pos + (cont*sizeof(Data)+sizeof(long));
    archive.seekp(aux,ios::beg);
    cout<<"Dir : "<<archive.tellg();cin.get();
    archive.write((char*)&data, sizeof(Data));
    cont++;
    archive.seekp(pos,ios::beg);
    archive.write((char*)&cont, sizeof(long));
    archive.close();
}

void Persona::print(Console& graphics) {
    ifstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
    int pos(0);
    long aux;
    int x=4,y=4;
    graphics.setColor(graphics.FG_DARK_CYAN);
    graphics.moveTo(2, 2);
    cout<<"  Fila\t      Rfc\t     Nombre\t      Phone     \tDireccion";
    graphics.moveTo(3, 2);
    cout<<"---------------------------------------------------------------------------";
    graphics.setColor(graphics.FG_WHITE);
    int A=0;
    while(!archive.eof()){
        archive.seekg(pos,ios::beg);
        archive.read((char*)&aux, sizeof(aux));
        if(archive.eof())break;
        if(aux>0){
            for(int i(0);i<aux;++i){
                archive.read((char*)&data, sizeof(Data));
                y=4;
                graphics.moveTo(x, y);
                cout<<A;
                y=14;
                graphics.moveTo(x, y);
                cout<<getRfc();
                y = 28;
                graphics.moveTo(x, y);
                cout<<getName();
                y= 47;
                graphics.moveTo(x, y);
                cout<<getPhone();
                y=60;
                graphics.moveTo(x, y);
                cout<<getAddress();
                x++;
            }
        }
         A++;
        pos=pos+(sizeof(Data)*columns+sizeof(long));
    }
    cin.get();
}

void Persona::mofify(std::string & modify) {
    long pos(getAddress(modify));
    if(pos==-1){
        throw invalid_argument("No se encontro ningun registro con este RFC");
    }
    string myStr;
    fstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt",ios::in|ios::out);
    if(getRfc()==modify){
        cout<<"Si jala"<<endl;
        cin.get();
        do{
            cout<<"\t\t\tMOdificar Registro"<<endl
            <<"\t1)Nombre"<<endl
            <<"\t2)Rfc"<<endl
            <<"\t3)Telefono"<<endl
            <<"\t4)Direccion"<<endl
            <<"\tElige una opcion : ";
            getline(cin,myStr);
            if(myStr=="1"){
                system("clear");
                cout<<"\tNombre actual : "<<getName()<<endl
                <<"\tNombre : ";
                getline(cin,myStr);
                setName(myStr);
            }else if(myStr=="2"){
                system("clear");
                do{
                    cout<<"\tRfc actual : "<<getRfc()<<endl
                    <<"\tRFC : ";
                    getline(cin,myStr);
                }while(isValidRfc(myStr));
                string nombre(getName()),telefono(getPhone()),direccion(getAddress());
                cout<<modify<<endl;cin.get();
                remove(modify);
                setRfc(myStr);
                setAddress(direccion);
                setName(nombre);
                setPhone(telefono);
                insert();
                return;
            }else if(myStr=="3"){
                system("clear");
                cout<<"Telefono actual : "<<getName()<<endl
                <<"Telefono : ";
                getline(cin,myStr);
                setPhone(myStr);
            }else if(myStr=="4"){
                system("clear");
                cout<<"Direccion actual : "<<getName()<<endl
                <<"Direccion : ";
                getline(cin,myStr);
                setAddress(myStr);
            }else if(myStr=="5"){
                
            }else{
                system("clear");
                cout<<"\tOpcion no valida "<<endl;
            }
        }while(myStr!="5");
        archive.seekg(pos);
        archive.write((char*)&data, sizeof(Data));
    }
    archive.close();
}

void Persona::remove(std::string &remove) {
    fstream archive("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt",ios::in|ios::out);
    long pos(dispersion(remove)*(columns*sizeof(data)+sizeof(long)));//(columns*sizeof(data))+sizeof(long));
    cout<<"pos : "<<pos;cin.get();
    long aux;
    archive.seekg(pos,ios::beg);
    archive.read((char*)&aux, sizeof(aux));
    cout<<"Aux : "<<aux;cin.get();
    if(aux>0){
        for(int i(0);i<aux;++i){
            aux=archive.tellg();
            archive.read((char*)&data, sizeof(Data));
            cout<<getRfc()<<endl;cin.get();
            if(getRfc()==remove){
                cout<<"Debe eliminar "<<endl;cin.get();
                if(aux==1||i==3){
                    archive.seekg(pos,ios::beg);
                    aux--;
                    archive.write((char*)&aux, sizeof(long));
                }else{
                    archive.seekg(pos,ios::beg);
                    archive.read((char*)&aux, sizeof(aux));
                    Data personas[3];
                    for(long i(0);i<aux;++i){
                        archive.read((char*)&personas[i], sizeof(Data));
                    }
                    aux--;
                    archive.seekg(pos,ios::beg);
                    archive.write((char*)&aux, sizeof(long));
                    for(long i(0);i<aux-1;++i){
                        if(remove!=personas[i].rfc)
                            archive.write((char*)&personas[i],sizeof(Data));
                    }
                }
                return;
            }
        }
    }
}

int Persona::dispersion(std::string key) {
    cout<<"Filas : "<<rows;
    cin.get();
    int i(0);
    long long int d_base(0);
    while(i<key.size()){
        d_base=d_base+(100*key[i])+(key[i+1]%87645);
        i+=2;
    }
    return d_base%rows;
}

void Persona::expandirColumnas(){
    ofstream archive("/Users/oscarsandoval/Desktop/tablasHash/Aux.txt",ios::out);
    const long aux=0;
    for(int i=0;i<rows;i++){
        archive.write((char*)&aux,sizeof(long));
        for(int j=0;j<columns*2;j++){
            archive.write((char*)&data,sizeof(data));
        }
    }
    archive.close();
    archive.open("/Users/oscarsandoval/Desktop/tablasHash/tablasHash/Colisiones.txt",ios::out);
    columns=columns*2;
    archive<<rows<<"|"<<columns;
    copyFile();
    std::remove("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
    rename("/Users/oscarsandoval/Desktop/tablasHash/Aux.txt", "/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
}

void Persona::expandirFilas(){
    ofstream archive("/Users/oscarsandoval/Desktop/tablasHash/Aux.txt",ios::out);
    const long aux=0;
    for(int i=0;i<rows*2;i++){
        archive.write((char*)&aux,sizeof(long));
        for(int j=0;j<4;j++){
            archive.write((char*)&data,sizeof(data));
        }
    }
    archive.close();
    archive.open("/Users/oscarsandoval/Desktop/tablasHash/tablasHash/Colisiones.txt",ios::out);
    rows=rows*2;
    archive<<rows<<"|"<<columns;
    copyFile();
    std::remove("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
    rename("/Users/oscarsandoval/Desktop/tablasHash/Aux.txt", "/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
}

void Persona::copyFile(){
    ifstream read("/Users/oscarsandoval/Desktop/tablasHash/Persona.txt");
    int pos(0);
    long aux;
    while(!read.eof()){
        read.seekg(pos,ios::beg);
        read.read((char*)&aux, sizeof(aux));
        if(read.eof())break;
        if(aux>0){
            for(int i(0);i<aux;++i){
                read.read((char*)&data, sizeof(Data));
                insertCopy();
            }
        }
        pos=pos+(sizeof(Data)*4+sizeof(long));
    }
}

void Persona::insertCopy(){
    fstream archive("/Users/oscarsandoval/Desktop/tablasHash/Aux.txt",ios::in|ios::out);
    int hash(dispersion(getRfc()));
    long pos(hash*(columns*sizeof(data)+sizeof(long)));
    long cont;
    archive.seekg(pos);
    archive.read((char*)&cont, sizeof(long));
    cout<<cont<<endl;
    cin.get();
    if(cont==columns){
        cout<<"\t│                   NO HAY ESPACIO                  │\n";
        archive.close();
        cin.get();
        return;
    }
    long aux = pos + (cont*sizeof(Data)+sizeof(long));
    archive.seekp(aux,ios::beg);
    cout<<"Dir : "<<archive.tellg();cin.get();
    archive.write((char*)&data, sizeof(Data));
    cont++;
    archive.seekp(pos,ios::beg);
    archive.write((char*)&cont, sizeof(long));
    archive.close();
}
